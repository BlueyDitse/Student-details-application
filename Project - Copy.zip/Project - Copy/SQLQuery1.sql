USE TheSpongebobsDB1;
GO
CREATE TABLE Modules
(
	module_Code NVARCHAR(6) NOT NULL,
	module_Name NVARCHAR(50) NOT NULL,
	module_NQF INT NOT NULL,
	module_Credits INT NOT NULL,
	module_Description NVARCHAR(MAX) NOT NULL
)
INSERT INTO Modules(module_Code,module_Name,module_NQF,module_Credits,module_Description)
VALUES
('WPR171','Web Programming 171',5,13,'The purpose of this course is to enable the student to design and develop web pages and/or websites.
The emphasis will be on layout, structure and content presentation. Good design principles will be
covered, as well as integration of multimedia elements in web pages. Additionally, the course will
cover basic web server concepts and the HTTP paradigm.'),
('PRG171','Programming 171',5,16,'The purpose of this module is to understand how software has helped people solve problems. The
student will learn several general concepts that will allow them to formulate and understanding of a
problem and develop an algorithm to support the solution. They will be introduced to arithmetic
used in programming, sequences, selection and iteration control structures with built in data types'),
('STA171','Statistics 171',5,4,'The overall purpose of the program is to produce graduates that can think clearly and critically and
apply the knowledge of Business Statistics in decision making when solving business problems and
build a culture of informed decision making using statistical models.'),
('INF181','Information Systems 171',5,12,'
The purpose of this course is to equip students with the knowledge and competencies to understand
Information Technology (IT) as a key enabler of business transformation. This course is designed to
introduce the key components of information systems and how these can be integrated and
managed to support business decisions and create competitive advantage. At the end of the course,
students will have an appreciation of the activities undertaken in acquiring and successful
implementation of an information system in organisations and society. '),
('MAT181','Mathematics 171',6,11,'Mathematics is an understanding of essential mathematical principles, mathematical thinking skills
and reasoning. It is the application of mathematical methods and techniques to computational,
business and applied mathematics problems. ')