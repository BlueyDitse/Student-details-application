USE TheSpongebobsTaskDB;
GO
INSERT INTO Students (student_Number, student_Name, student_Surname, student_Photo, student_DOB, student_Gender, student_Phone, student_Address)
VALUES
(1001, 'Lerato', 'Moloi', 0x, '1990-05-15', 'Female', '1234567890', '123 Main Street, Johannesburg'),

(1002, 'Thabo', 'Ngwenya', 0x, '1992-08-22', 'Male', '9876543210', '456 Oak Avenue, Pretoria'),

(1003, 'Naledi', 'Modise', 0x, '1991-03-10', 'Female', '7654321098', '789 Pine Road, Cape Town'),

(1004, 'Sipho', 'Dlamini', 0x, '1993-12-05', 'Male', '6543210987', '234 Cedar Lane, Durban'),

(1005, 'Tumi', 'Molefe', 0x, '1990-07-18', 'Female', '2345678901', '567 Birch Street, Bloemfontein'),

(1006, 'Musa', 'Zulu', 0x, '1992-01-30', 'Male', '8765432109', '890 Elm Court, Port Elizabeth'),

(1007, 'Lebohang', 'Mkhize', 0x, '1993-09-12', 'Female', '3456789012', '678 Maple Avenue, East London'),

(1008, 'Khaya', 'Sithole', 0x, '1991-06-25', 'Male', '5678901234', '901 Pinecrest Road, Kimberley'),

(1009, 'Nomfundo', 'Mncube', 0x, '1990-04-03', 'Female', '4321098765', '123 Willow Lane, Nelspruit'),

(1010, 'Bongani', 'Nkosi', 0x, '1992-11-20', 'Male', '7890123456', '456 Cedar Avenue, Polokwane');