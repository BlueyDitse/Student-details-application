﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheSpongebobs_Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            string username = passwordTB.Text;
            string password = passwordTB.Text;

            if (IsValidUser(username, password))
            {
                MessageBox.Show("Login succesful!");
                this.Hide();
                SelectorForm selectorForm = new SelectorForm();
                selectorForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }

        }
        private bool IsValidUser(string username, string password)
        {
            string[] lines = File.ReadAllLines("userCredentials.txt");
            foreach (string line in lines)
            {
                string[] parts = line.Split(',');
                if (parts.Length == 2)
                {
                    string storedUsername = parts[0];
                    string storedPassword = parts[1];

                    if (storedUsername == username && storedPassword == password)
                    { return true; }
                }
            }
            return false;
        }
        private void registerBtn_Click(object sender, EventArgs e)
        {

            string username = passwordTB.Text;
            string password = passwordTB.Text;

            if (InsertUser(username, password))
            {
                MessageBox.Show("Registration successful!");
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
        }

        private bool InsertUser(string username, string password)
        {
            if (IsValidUser(username, ""))
            {
                MessageBox.Show("A user with this username already exists");
                return false;
            }
            File.AppendAllText("userCredentials.txt", $"{username},{password}\n");
            return true;
        }
    }
}







