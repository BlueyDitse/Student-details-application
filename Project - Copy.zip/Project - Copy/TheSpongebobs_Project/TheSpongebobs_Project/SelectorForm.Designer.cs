﻿namespace TheSpongebobs_Project
{
    partial class SelectorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.studentDetBtn = new System.Windows.Forms.Button();
            this.moduleDetBtn = new System.Windows.Forms.Button();
            this.moduleDetPB = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.moduleDetPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // studentDetBtn
            // 
            this.studentDetBtn.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.studentDetBtn.Font = new System.Drawing.Font("Futura Md BT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentDetBtn.ForeColor = System.Drawing.Color.White;
            this.studentDetBtn.Location = new System.Drawing.Point(76, 338);
            this.studentDetBtn.Name = "studentDetBtn";
            this.studentDetBtn.Size = new System.Drawing.Size(207, 76);
            this.studentDetBtn.TabIndex = 0;
            this.studentDetBtn.Text = "Manage Student Details";
            this.studentDetBtn.UseVisualStyleBackColor = false;
            // 
            // moduleDetBtn
            // 
            this.moduleDetBtn.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.moduleDetBtn.Font = new System.Drawing.Font("Futura Md BT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moduleDetBtn.ForeColor = System.Drawing.Color.White;
            this.moduleDetBtn.Location = new System.Drawing.Point(463, 338);
            this.moduleDetBtn.Name = "moduleDetBtn";
            this.moduleDetBtn.Size = new System.Drawing.Size(207, 76);
            this.moduleDetBtn.TabIndex = 1;
            this.moduleDetBtn.Text = "Manage Module\r\nDetails";
            this.moduleDetBtn.UseVisualStyleBackColor = false;
            // 
            // moduleDetPB
            // 
            this.moduleDetPB.BackgroundImage = global::TheSpongebobs_Project.Properties.Resources.Screenshot_2023_11_13_2043451;
            this.moduleDetPB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.moduleDetPB.Location = new System.Drawing.Point(430, 73);
            this.moduleDetPB.Name = "moduleDetPB";
            this.moduleDetPB.Size = new System.Drawing.Size(275, 241);
            this.moduleDetPB.TabIndex = 2;
            this.moduleDetPB.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::TheSpongebobs_Project.Properties.Resources.d0f5ef39684ca4c438d429307f3ef2ba;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(44, 73);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(275, 241);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // SelectorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TheSpongebobs_Project.Properties.Resources._8fd198938864cdbfcda19bb9d242465a2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 485);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.moduleDetPB);
            this.Controls.Add(this.moduleDetBtn);
            this.Controls.Add(this.studentDetBtn);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SelectorForm";
            this.Text = "SelectorForm";
            ((System.ComponentModel.ISupportInitialize)(this.moduleDetPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button studentDetBtn;
        private System.Windows.Forms.Button moduleDetBtn;
        private System.Windows.Forms.PictureBox moduleDetPB;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}