﻿namespace TheSpongebobs_Project
{
    partial class StudentInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.searchBtn = new System.Windows.Forms.Button();
            this.studentNoLbl = new System.Windows.Forms.Label();
            this.studentNoTB = new System.Windows.Forms.TextBox();
            this.studentInfoLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.moduleGB = new System.Windows.Forms.GroupBox();
            this.removeBtn = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.viewBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.createBtn = new System.Windows.Forms.Button();
            this.modulesCB = new System.Windows.Forms.ComboBox();
            this.genderLbl = new System.Windows.Forms.Label();
            this.dobLbl = new System.Windows.Forms.Label();
            this.photoLbl = new System.Windows.Forms.Label();
            this.surnameLbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.studentPhoto = new System.Windows.Forms.PictureBox();
            this.phoneLbl = new System.Windows.Forms.Label();
            this.adressLbl = new System.Windows.Forms.Label();
            this.idLbl = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.adressTB = new System.Windows.Forms.TextBox();
            this.phoneTB = new System.Windows.Forms.TextBox();
            this.genderCB = new System.Windows.Forms.ComboBox();
            this.dobPicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.moduleGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(304, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(417, 325);
            this.dataGridView1.TabIndex = 1;
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.Snow;
            this.searchBtn.Font = new System.Drawing.Font("Futura Md BT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBtn.Location = new System.Drawing.Point(603, 26);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(125, 28);
            this.searchBtn.TabIndex = 8;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // studentNoLbl
            // 
            this.studentNoLbl.AutoSize = true;
            this.studentNoLbl.BackColor = System.Drawing.Color.Transparent;
            this.studentNoLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentNoLbl.ForeColor = System.Drawing.Color.White;
            this.studentNoLbl.Location = new System.Drawing.Point(311, 31);
            this.studentNoLbl.Name = "studentNoLbl";
            this.studentNoLbl.Size = new System.Drawing.Size(85, 18);
            this.studentNoLbl.TabIndex = 7;
            this.studentNoLbl.Text = "Student ID\r\n";
            this.studentNoLbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // studentNoTB
            // 
            this.studentNoTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentNoTB.Location = new System.Drawing.Point(419, 26);
            this.studentNoTB.Name = "studentNoTB";
            this.studentNoTB.Size = new System.Drawing.Size(168, 26);
            this.studentNoTB.TabIndex = 6;
            this.studentNoTB.TextChanged += new System.EventHandler(this.moduleCodeTB_TextChanged);
            // 
            // studentInfoLbl
            // 
            this.studentInfoLbl.AutoSize = true;
            this.studentInfoLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.studentInfoLbl.Font = new System.Drawing.Font("Futura Md BT", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentInfoLbl.ForeColor = System.Drawing.Color.White;
            this.studentInfoLbl.Location = new System.Drawing.Point(-3, -1);
            this.studentInfoLbl.Name = "studentInfoLbl";
            this.studentInfoLbl.Size = new System.Drawing.Size(302, 35);
            this.studentInfoLbl.TabIndex = 9;
            this.studentInfoLbl.Text = "Student Information";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Snow;
            this.backBtn.Font = new System.Drawing.Font("Futura Md BT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(419, 393);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(173, 41);
            this.backBtn.TabIndex = 10;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = false;
            // 
            // moduleGB
            // 
            this.moduleGB.BackColor = System.Drawing.Color.Transparent;
            this.moduleGB.Controls.Add(this.modulesCB);
            this.moduleGB.Controls.Add(this.removeBtn);
            this.moduleGB.Controls.Add(this.addBtn);
            this.moduleGB.Controls.Add(this.dataGridView2);
            this.moduleGB.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moduleGB.ForeColor = System.Drawing.Color.White;
            this.moduleGB.Location = new System.Drawing.Point(3, 320);
            this.moduleGB.Name = "moduleGB";
            this.moduleGB.Size = new System.Drawing.Size(295, 82);
            this.moduleGB.TabIndex = 25;
            this.moduleGB.TabStop = false;
            this.moduleGB.Text = "Module List";
            // 
            // removeBtn
            // 
            this.removeBtn.BackColor = System.Drawing.Color.IndianRed;
            this.removeBtn.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.removeBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.removeBtn.Location = new System.Drawing.Point(199, 48);
            this.removeBtn.Name = "removeBtn";
            this.removeBtn.Size = new System.Drawing.Size(90, 28);
            this.removeBtn.TabIndex = 21;
            this.removeBtn.Text = "Remove ";
            this.removeBtn.UseVisualStyleBackColor = false;
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.addBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.Location = new System.Drawing.Point(199, 20);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(90, 28);
            this.addBtn.TabIndex = 21;
            this.addBtn.Text = "Add Module";
            this.addBtn.UseVisualStyleBackColor = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(7, 42);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(171, 34);
            this.dataGridView2.TabIndex = 21;
            // 
            // viewBtn
            // 
            this.viewBtn.BackColor = System.Drawing.Color.Snow;
            this.viewBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewBtn.Location = new System.Drawing.Point(84, 408);
            this.viewBtn.Name = "viewBtn";
            this.viewBtn.Size = new System.Drawing.Size(68, 28);
            this.viewBtn.TabIndex = 24;
            this.viewBtn.Text = "View";
            this.viewBtn.UseVisualStyleBackColor = false;
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Snow;
            this.updateBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.Location = new System.Drawing.Point(158, 408);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(68, 28);
            this.updateBtn.TabIndex = 23;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.IndianRed;
            this.deleteBtn.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.deleteBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.deleteBtn.Location = new System.Drawing.Point(230, 408);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(68, 28);
            this.deleteBtn.TabIndex = 22;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            // 
            // createBtn
            // 
            this.createBtn.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.createBtn.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createBtn.Location = new System.Drawing.Point(10, 408);
            this.createBtn.Name = "createBtn";
            this.createBtn.Size = new System.Drawing.Size(68, 28);
            this.createBtn.TabIndex = 21;
            this.createBtn.Text = "Create";
            this.createBtn.UseVisualStyleBackColor = false;
            // 
            // modulesCB
            // 
            this.modulesCB.FormattingEnabled = true;
            this.modulesCB.Location = new System.Drawing.Point(7, 20);
            this.modulesCB.Name = "modulesCB";
            this.modulesCB.Size = new System.Drawing.Size(171, 22);
            this.modulesCB.TabIndex = 26;
            // 
            // genderLbl
            // 
            this.genderLbl.AutoSize = true;
            this.genderLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.genderLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLbl.ForeColor = System.Drawing.Color.White;
            this.genderLbl.Location = new System.Drawing.Point(6, 241);
            this.genderLbl.Name = "genderLbl";
            this.genderLbl.Size = new System.Drawing.Size(63, 18);
            this.genderLbl.TabIndex = 35;
            this.genderLbl.Text = "Gender";
            this.genderLbl.Click += new System.EventHandler(this.genderLbl_Click);
            // 
            // dobLbl
            // 
            this.dobLbl.AutoSize = true;
            this.dobLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.dobLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dobLbl.ForeColor = System.Drawing.Color.White;
            this.dobLbl.Location = new System.Drawing.Point(6, 213);
            this.dobLbl.Name = "dobLbl";
            this.dobLbl.Size = new System.Drawing.Size(106, 18);
            this.dobLbl.TabIndex = 34;
            this.dobLbl.Text = "Date Of Birth";
            this.dobLbl.Click += new System.EventHandler(this.dobLbl_Click);
            // 
            // photoLbl
            // 
            this.photoLbl.AutoSize = true;
            this.photoLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.photoLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.photoLbl.ForeColor = System.Drawing.Color.White;
            this.photoLbl.Location = new System.Drawing.Point(6, 111);
            this.photoLbl.Name = "photoLbl";
            this.photoLbl.Size = new System.Drawing.Size(50, 18);
            this.photoLbl.TabIndex = 33;
            this.photoLbl.Text = "Photo";
            this.photoLbl.Click += new System.EventHandler(this.nqfLbl_Click);
            // 
            // surnameLbl
            // 
            this.surnameLbl.AutoSize = true;
            this.surnameLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.surnameLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surnameLbl.ForeColor = System.Drawing.Color.White;
            this.surnameLbl.Location = new System.Drawing.Point(6, 58);
            this.surnameLbl.Name = "surnameLbl";
            this.surnameLbl.Size = new System.Drawing.Size(135, 18);
            this.surnameLbl.TabIndex = 32;
            this.surnameLbl.Text = "Student Surname";
            this.surnameLbl.Click += new System.EventHandler(this.moduleNameLbl_Click);
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.nameLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.ForeColor = System.Drawing.Color.White;
            this.nameLbl.Location = new System.Drawing.Point(6, 36);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(114, 18);
            this.nameLbl.TabIndex = 31;
            this.nameLbl.Text = "Student Name";
            this.nameLbl.Click += new System.EventHandler(this.moduleCode1Lbl_Click);
            // 
            // studentPhoto
            // 
            this.studentPhoto.Location = new System.Drawing.Point(62, 111);
            this.studentPhoto.Name = "studentPhoto";
            this.studentPhoto.Size = new System.Drawing.Size(115, 99);
            this.studentPhoto.TabIndex = 36;
            this.studentPhoto.TabStop = false;
            // 
            // phoneLbl
            // 
            this.phoneLbl.AutoSize = true;
            this.phoneLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.phoneLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneLbl.ForeColor = System.Drawing.Color.White;
            this.phoneLbl.Location = new System.Drawing.Point(7, 269);
            this.phoneLbl.Name = "phoneLbl";
            this.phoneLbl.Size = new System.Drawing.Size(54, 18);
            this.phoneLbl.TabIndex = 37;
            this.phoneLbl.Text = "Phone";
            // 
            // adressLbl
            // 
            this.adressLbl.AutoSize = true;
            this.adressLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.adressLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adressLbl.ForeColor = System.Drawing.Color.White;
            this.adressLbl.Location = new System.Drawing.Point(7, 299);
            this.adressLbl.Name = "adressLbl";
            this.adressLbl.Size = new System.Drawing.Size(58, 18);
            this.adressLbl.TabIndex = 38;
            this.adressLbl.Text = "Adress";
            // 
            // idLbl
            // 
            this.idLbl.AutoSize = true;
            this.idLbl.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.idLbl.Font = new System.Drawing.Font("Futura Md BT", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLbl.ForeColor = System.Drawing.Color.White;
            this.idLbl.Location = new System.Drawing.Point(6, 90);
            this.idLbl.Name = "idLbl";
            this.idLbl.Size = new System.Drawing.Size(89, 18);
            this.idLbl.TabIndex = 39;
            this.idLbl.Text = "ID Number";
            this.idLbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(145, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(154, 21);
            this.textBox1.TabIndex = 40;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(145, 58);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(154, 21);
            this.textBox3.TabIndex = 42;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(144, 90);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(154, 21);
            this.textBox2.TabIndex = 43;
            // 
            // adressTB
            // 
            this.adressTB.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adressTB.Location = new System.Drawing.Point(118, 299);
            this.adressTB.Name = "adressTB";
            this.adressTB.Size = new System.Drawing.Size(181, 21);
            this.adressTB.TabIndex = 45;
            this.adressTB.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // phoneTB
            // 
            this.phoneTB.Font = new System.Drawing.Font("Futura Md BT", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneTB.Location = new System.Drawing.Point(118, 269);
            this.phoneTB.Name = "phoneTB";
            this.phoneTB.Size = new System.Drawing.Size(181, 21);
            this.phoneTB.TabIndex = 46;
            // 
            // genderCB
            // 
            this.genderCB.FormattingEnabled = true;
            this.genderCB.Location = new System.Drawing.Point(118, 241);
            this.genderCB.Name = "genderCB";
            this.genderCB.Size = new System.Drawing.Size(181, 21);
            this.genderCB.TabIndex = 48;
            // 
            // dobPicker
            // 
            this.dobPicker.Location = new System.Drawing.Point(118, 215);
            this.dobPicker.Name = "dobPicker";
            this.dobPicker.Size = new System.Drawing.Size(181, 20);
            this.dobPicker.TabIndex = 49;
            // 
            // StudentInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TheSpongebobs_Project.Properties.Resources._8fd198938864cdbfcda19bb9d242465a2;
            this.ClientSize = new System.Drawing.Size(733, 446);
            this.Controls.Add(this.dobPicker);
            this.Controls.Add(this.genderCB);
            this.Controls.Add(this.phoneTB);
            this.Controls.Add(this.adressTB);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.idLbl);
            this.Controls.Add(this.adressLbl);
            this.Controls.Add(this.phoneLbl);
            this.Controls.Add(this.studentPhoto);
            this.Controls.Add(this.genderLbl);
            this.Controls.Add(this.dobLbl);
            this.Controls.Add(this.photoLbl);
            this.Controls.Add(this.surnameLbl);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.moduleGB);
            this.Controls.Add(this.viewBtn);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.createBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.studentInfoLbl);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.studentNoLbl);
            this.Controls.Add(this.studentNoTB);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentInformation";
            this.Text = "StudentInformation";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.moduleGB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Label studentNoLbl;
        private System.Windows.Forms.TextBox studentNoTB;
        private System.Windows.Forms.Label studentInfoLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.GroupBox moduleGB;
        private System.Windows.Forms.ComboBox modulesCB;
        private System.Windows.Forms.Button removeBtn;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button viewBtn;
        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button createBtn;
        private System.Windows.Forms.Label genderLbl;
        private System.Windows.Forms.Label dobLbl;
        private System.Windows.Forms.Label photoLbl;
        private System.Windows.Forms.Label surnameLbl;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.PictureBox studentPhoto;
        private System.Windows.Forms.Label phoneLbl;
        private System.Windows.Forms.Label adressLbl;
        private System.Windows.Forms.Label idLbl;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox adressTB;
        private System.Windows.Forms.TextBox phoneTB;
        private System.Windows.Forms.ComboBox genderCB;
        private System.Windows.Forms.DateTimePicker dobPicker;
    }
}